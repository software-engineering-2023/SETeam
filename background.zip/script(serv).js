const wrapper = document.querySelector(".wrapper");
const btnPopup = document.querySelector(".btn");
const iconClose = document.querySelector(".icon-close");

btnPopup.addEventListener("click", () => {
  wrapper.classList.add("active-popup");
});

iconClose.addEventListener("click", () => {
  wrapper.classList.remove("active-popup");
});

const wrapper2 = document.querySelector(".wrapper2");
const btnPopup2 = document.querySelector(".btn2");
const iconClose2 = document.querySelector(".icon-close2");

btnPopup2.addEventListener("click", () => {
  wrapper2.classList.add("active-popup");
});

iconClose2.addEventListener("click", () => {
  wrapper2.classList.remove("active-popup");
});

const wrapper8 = document.querySelector(".wrapper8");
const btnPopup8 = document.querySelector(".btn8");
const iconClose8 = document.querySelector(".icon-close8");
const diffBankLink = document.querySelector(".diff-bank");
const sameBankLink = document.querySelector(".same-bank");

btnPopup8.addEventListener("click", () => {
  wrapper8.classList.add("active-popup");
});

diffBankLink.addEventListener("click", () => {
  wrapper8.classList.add("active");
});

sameBankLink.addEventListener("click", () => {
  wrapper8.classList.remove("active");
});

iconClose8.addEventListener("click", () => {
  wrapper8.classList.remove("active-popup");
});

const goHomeLogin = () => {
  window.location = "./Page2.html";
};

const wrapper9 = document.querySelector(".wrapper9");
const btnPopup9 = document.querySelector(".btn9");
const iconClose9 = document.querySelector(".icon-close9");

btnPopup9.addEventListener("click", () => {
  wrapper9.classList.add("active-popup");
});

iconClose9.addEventListener("click", () => {
  wrapper9.classList.remove("active-popup");
});

const contactLogin = () => {
  window.location = "./contactLogin.html";
};
const wrapper3 = document.querySelector(".wrapper3");
const btnPopup3 = document.querySelector(".btn3");
const iconClose3 = document.querySelector(".icon-close3");

btnPopup3.addEventListener("click", () => {
  wrapper3.classList.add("active-popup");
});

iconClose3.addEventListener("click", () => {
  wrapper3.classList.remove("active-popup");
});

const wrapper4 = document.querySelector(".wrapper4");
const btnPopup4 = document.querySelector(".btn4");
const iconClose4 = document.querySelector(".icon-close4");

btnPopup4.addEventListener("click", () => {
  wrapper4.classList.add("active-popup");
});

iconClose4.addEventListener("click", () => {
  wrapper4.classList.remove("active-popup");
});

const goServMain = () => {
  window.location = "./Services.html";
};

const goContact = () => {
  window.location = "./contactLogin.html";
};

btnPopup.addEventListener("click", () => {
  wrapper2.classList.add("active-popup");
});

iconClose.addEventListener("click", () => {
  wrapper2.classList.remove("active-popup");
});
