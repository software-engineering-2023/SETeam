const goHomeLogin = () =>{
    window.location = "./main.html"
}

const goServMain = () =>{
    window.location = "./Services(main).html"
}