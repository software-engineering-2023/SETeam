const loginFirstAlert = () => {
    alert('You must login first')
}

const goHome = () => {
    window.location = "./main.html" 
}

const contactMain = () => {
    window.location = "./contactUs.html" 
}