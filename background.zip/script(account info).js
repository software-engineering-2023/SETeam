const goHomeLogin = () => {
    window.location = "./Page2.html" 
}   

const goServLogin = () => {
    window.location = "./Services.html" 
} 

const contactLogin = () => {
    window.location = "./contactLogin.html" 
} 


