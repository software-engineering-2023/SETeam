const goHomeLogin = () =>{
    window.location = "./page2.html"
}

const goServMain = () =>{
    window.location = "./Services.html"
}